import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../../domain/entities/mushaf_line.dart';

class MushafLayoutDataSource {
  MushafLayoutDataSource._();

  static final MushafLayoutDataSource instance = MushafLayoutDataSource._();

  static const String _layoutAssetPath =
      'assets/quran/v4/layout/qpc-v4-tajweed-15-lines.db';

  static const String _wordsAssetPath = 'assets/quran/v4/words/qpc-v4.db';

  static const String _layoutDbFileName = 'qpc-v4-tajweed-15-lines.db';

  static const String _wordsDbFileName = 'qpc-v4.db';

  Database? _layoutDb;
  Database? _wordsDb;

  Future<List<MushafLine>> getPageLines(int pageNumber) async {
    if (pageNumber < 1 || pageNumber > 604) {
      throw ArgumentError.value(
        pageNumber,
        'pageNumber',
        'Mushaf page must be between 1 and 604.',
      );
    }

    await _ensureDatabasesOpen();

    final layoutRows = await _layoutDb!.query(
      'pages',
      where: 'page_number = ?',
      whereArgs: [pageNumber],
      orderBy: 'line_number ASC',
    );

    if (layoutRows.isEmpty) {
      throw StateError('No QPC V4 layout rows found for page $pageNumber.');
    }

    int? minWordId;
    int? maxWordId;

    for (final row in layoutRows) {
      final lineType = row['line_type']?.toString();

      if (lineType != 'ayah') {
        continue;
      }

      final firstWordId = _toNullableInt(row['first_word_id']);

      final lastWordId = _toNullableInt(row['last_word_id']);

      if (firstWordId == null || lastWordId == null) {
        continue;
      }

      if (minWordId == null || firstWordId < minWordId) {
        minWordId = firstWordId;
      }

      if (maxWordId == null || lastWordId > maxWordId) {
        maxWordId = lastWordId;
      }
    }

    final Map<int, String> glyphsByWordId = {};

    if (minWordId != null && maxWordId != null) {
      final wordRows = await _wordsDb!.query(
        'words',
        columns: ['id', 'text'],
        where: 'id >= ? AND id <= ?',
        whereArgs: [minWordId, maxWordId],
        orderBy: 'id ASC',
      );

      for (final row in wordRows) {
        final id = _toNullableInt(row['id']);

        if (id == null) {
          continue;
        }

        final glyph = row['text']?.toString() ?? '';

        glyphsByWordId[id] = glyph;
      }
    }

    final lines = <MushafLine>[];

    for (final row in layoutRows) {
      final lineNumber = _toInt(row['line_number']);

      final lineType = row['line_type']?.toString() ?? '';

      final isCentered = _toBool(row['is_centered']);

      final surahNumber = _toNullableInt(row['surah_number']);

      String text = '';

      if (lineType == 'ayah') {
        final firstWordId = _toNullableInt(row['first_word_id']);

        final lastWordId = _toNullableInt(row['last_word_id']);

        if (firstWordId == null || lastWordId == null) {
          throw StateError(
            'Invalid ayah word range on page $pageNumber '
            'line $lineNumber.',
          );
        }

        final lineGlyphs = <String>[];

        for (var wordId = firstWordId; wordId <= lastWordId; wordId++) {
          final glyph = glyphsByWordId[wordId];

          if (glyph == null || glyph.isEmpty) {
            throw StateError(
              'Missing QPC V4 glyph for word id $wordId '
              'on page $pageNumber line $lineNumber.',
            );
          }

          lineGlyphs.add(glyph);
        }

        text = lineGlyphs.join(' ');
      }

      lines.add(
        MushafLine(
          pageNumber: pageNumber,
          lineNumber: lineNumber,
          lineType: lineType,
          isCentered: isCentered,
          surahNumber: surahNumber,
          text: text,
        ),
      );
    }

    return lines;
  }

  Future<void> _ensureDatabasesOpen() async {
    if (_layoutDb != null && _wordsDb != null) {
      return;
    }

    final databasesPath = await getDatabasesPath();

    final mushafDirectory = Directory(p.join(databasesPath, 'quran', 'v4'));

    if (!await mushafDirectory.exists()) {
      await mushafDirectory.create(recursive: true);
    }

    final layoutDbPath = p.join(mushafDirectory.path, _layoutDbFileName);

    final wordsDbPath = p.join(mushafDirectory.path, _wordsDbFileName);

    await _copyAssetDatabaseIfNeeded(
      assetPath: _layoutAssetPath,
      destinationPath: layoutDbPath,
    );

    await _copyAssetDatabaseIfNeeded(
      assetPath: _wordsAssetPath,
      destinationPath: wordsDbPath,
    );

    _layoutDb ??= await openDatabase(layoutDbPath, readOnly: true);

    _wordsDb ??= await openDatabase(wordsDbPath, readOnly: true);
  }

  Future<void> _copyAssetDatabaseIfNeeded({
    required String assetPath,
    required String destinationPath,
  }) async {
    final destinationFile = File(destinationPath);

    if (await destinationFile.exists()) {
      return;
    }

    final data = await rootBundle.load(assetPath);

    final bytes = data.buffer.asUint8List(
      data.offsetInBytes,
      data.lengthInBytes,
    );

    await destinationFile.writeAsBytes(bytes, flush: true);
  }

  int _toInt(Object? value) {
    if (value is int) {
      return value;
    }

    if (value is num) {
      return value.toInt();
    }

    return int.parse(value.toString());
  }

  int? _toNullableInt(Object? value) {
    if (value == null) {
      return null;
    }

    final stringValue = value.toString().trim();

    if (stringValue.isEmpty) {
      return null;
    }

    if (value is int) {
      return value;
    }

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(stringValue);
  }

  bool _toBool(Object? value) {
    if (value is bool) {
      return value;
    }

    if (value is num) {
      return value != 0;
    }

    final normalized = value?.toString().trim().toLowerCase();

    return normalized == '1' || normalized == 'true';
  }

  Future<void> close() async {
    await _layoutDb?.close();
    await _wordsDb?.close();

    _layoutDb = null;
    _wordsDb = null;
  }
}
