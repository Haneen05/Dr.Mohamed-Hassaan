import 'package:flutter/services.dart';

enum QpcV4FontMode { normal, night }

class QpcV4FontLoader {
  QpcV4FontLoader._();

  static final QpcV4FontLoader instance = QpcV4FontLoader._();

  final Map<String, Future<String>> _fontCache = {};

  Future<String> loadPageFont(
    int pageNumber, {
    QpcV4FontMode mode = QpcV4FontMode.normal,
  }) {
    assert(
      pageNumber >= 1 && pageNumber <= 604,
      'QPC V4 page number must be between 1 and 604.',
    );

    final cacheKey = '${mode.name}_$pageNumber';

    return _fontCache.putIfAbsent(
      cacheKey,
      () => _loadFont(pageNumber: pageNumber, mode: mode),
    );
  }

  Future<String> _loadFont({
    required int pageNumber,
    required QpcV4FontMode mode,
  }) async {
    final fontFamily = _fontFamily(pageNumber: pageNumber, mode: mode);

    final loader = FontLoader(fontFamily);

    loader.addFont(
      rootBundle.load(_fontAssetPath(pageNumber: pageNumber, mode: mode)),
    );

    await loader.load();

    return fontFamily;
  }

  String _fontAssetPath({
    required int pageNumber,
    required QpcV4FontMode mode,
  }) {
    switch (mode) {
      case QpcV4FontMode.normal:
        return 'assets/quran/v4/fonts/p$pageNumber.ttf';
      case QpcV4FontMode.night:
        return 'assets/quran/v4/fonts_night/p$pageNumber.ttf';
    }
  }

  String _fontFamily({required int pageNumber, required QpcV4FontMode mode}) {
    switch (mode) {
      case QpcV4FontMode.normal:
        return 'QPC_V4_PAGE_$pageNumber';
      case QpcV4FontMode.night:
        return 'QPC_V4_NIGHT_PAGE_$pageNumber';
    }
  }

  bool isLoaded(int pageNumber, {QpcV4FontMode mode = QpcV4FontMode.normal}) {
    return _fontCache.containsKey('${mode.name}_$pageNumber');
  }

  void clearCache() {
    _fontCache.clear();
  }
}
