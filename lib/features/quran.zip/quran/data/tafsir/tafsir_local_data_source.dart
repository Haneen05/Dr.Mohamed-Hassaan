import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

enum TafsirType { saadi, ibnKathir }

class TafsirLocalDataSource {
  TafsirLocalDataSource._();

  static final TafsirLocalDataSource instance = TafsirLocalDataSource._();

  static const String _saadiAssetPath =
      'assets/quran/tafsir/ar-tafseer-al-saddi.db';

  static const String _ibnKathirAssetPath =
      'assets/quran/tafsir/ar-tafsir-ibn-kathir.db';

  static const String _saadiDbFileName = 'ar-tafseer-al-saddi.db';

  static const String _ibnKathirDbFileName = 'ar-tafsir-ibn-kathir.db';

  Database? _saadiDb;
  Database? _ibnKathirDb;

  Future<String?> getTafsir({
    required TafsirType type,
    required int surahNumber,
    required int ayahNumber,
  }) async {
    final db = await _getDatabase(type);

    final ayahKey = '$surahNumber:$ayahNumber';

    final exactRows = await db.query(
      'tafsir',
      where: 'ayah_key = ?',
      whereArgs: [ayahKey],
      limit: 1,
    );

    if (exactRows.isNotEmpty) {
      return _cleanText(exactRows.first['text']?.toString());
    }

    final allRows = await db.query(
      'tafsir',
      where: 'from_ayah <= ? AND to_ayah >= ?',
      whereArgs: [ayahNumber, ayahNumber],
    );

    for (final row in allRows) {
      final keys = row['ayah_keys']?.toString();

      if (keys == null || keys.isEmpty) {
        continue;
      }

      if (_containsAyahKey(keys, ayahKey)) {
        return _cleanText(row['text']?.toString());
      }
    }

    return null;
  }

  Future<Database> _getDatabase(TafsirType type) async {
    switch (type) {
      case TafsirType.saadi:
        _saadiDb ??= await _openAssetDatabase(
          assetPath: _saadiAssetPath,
          fileName: _saadiDbFileName,
        );

        return _saadiDb!;

      case TafsirType.ibnKathir:
        _ibnKathirDb ??= await _openAssetDatabase(
          assetPath: _ibnKathirAssetPath,
          fileName: _ibnKathirDbFileName,
        );

        return _ibnKathirDb!;
    }
  }

  Future<Database> _openAssetDatabase({
    required String assetPath,
    required String fileName,
  }) async {
    final databasesPath = await getDatabasesPath();

    final directory = Directory(p.join(databasesPath, 'quran', 'tafsir'));

    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }

    final databasePath = p.join(directory.path, fileName);

    final databaseFile = File(databasePath);

    if (!await databaseFile.exists()) {
      final data = await rootBundle.load(assetPath);

      final bytes = data.buffer.asUint8List(
        data.offsetInBytes,
        data.lengthInBytes,
      );

      await databaseFile.writeAsBytes(bytes, flush: true);
    }

    return openDatabase(databasePath, readOnly: true);
  }

  bool _containsAyahKey(String value, String ayahKey) {
    final normalized = value
        .replaceAll('[', '')
        .replaceAll(']', '')
        .replaceAll('"', '')
        .replaceAll("'", '');

    final keys = normalized.split(',').map((item) => item.trim());

    return keys.contains(ayahKey);
  }

  String? _cleanText(String? value) {
    if (value == null || value.trim().isEmpty) {
      return null;
    }

    var text = value;

    text = text.replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');

    text = text.replaceAll(RegExp(r'</p>', caseSensitive: false), '\n\n');

    text = text.replaceAll(RegExp(r'<[^>]*>'), '');

    text = text
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>');

    text = text.replaceAll(RegExp(r'\n{3,}'), '\n\n');

    return text.trim();
  }

  Future<void> close() async {
    await _saadiDb?.close();
    await _ibnKathirDb?.close();

    _saadiDb = null;
    _ibnKathirDb = null;
  }
}
