class MushafLine {
  const MushafLine({
    required this.pageNumber,
    required this.lineNumber,
    required this.lineType,
    required this.isCentered,
    required this.surahNumber,
    required this.text,
  });

  final int pageNumber;
  final int lineNumber;
  final String lineType;
  final bool isCentered;
  final int? surahNumber;
  final String text;

  bool get isAyah => lineType == 'ayah';

  bool get isSurahName => lineType == 'surah_name';

  bool get isBasmallah => lineType == 'basmallah';
}
