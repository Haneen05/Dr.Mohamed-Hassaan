import 'package:flutter/material.dart';
import 'package:qcf_quran/qcf_quran.dart';

import '../../../../../core/localization/app_localizations.dart';
import '../../../data/mushaf/mushaf_layout_data_source.dart';
import '../../../data/mushaf/qpc_v4_font_loader.dart';
import '../../../data/settings/mushaf_settings_local_data_source.dart';
import '../../../domain/entities/mushaf_line.dart';

class FixedQcfPage extends StatefulWidget {
  const FixedQcfPage({
    super.key,
    required this.pageNumber,
    required this.readingMode,
  });

  final int pageNumber;
  final MushafReadingMode readingMode;

  @override
  State<FixedQcfPage> createState() => _FixedQcfPageState();
}

class _FixedQcfPageState extends State<FixedQcfPage> {
  late Future<_MushafPageData> _pageFuture;

  @override
  void initState() {
    super.initState();
    _pageFuture = _loadPage();
  }

  @override
  void didUpdateWidget(covariant FixedQcfPage oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.pageNumber != widget.pageNumber ||
        oldWidget.readingMode != widget.readingMode) {
      _pageFuture = _loadPage();
    }
  }

  Future<_MushafPageData> _loadPage() async {
    final fontMode = widget.readingMode == MushafReadingMode.night
        ? QpcV4FontMode.night
        : QpcV4FontMode.normal;

    final results = await Future.wait([
      MushafLayoutDataSource.instance.getPageLines(widget.pageNumber),
      QpcV4FontLoader.instance.loadPageFont(
        widget.pageNumber,
        mode: fontMode,
      ),
    ]);

    return _MushafPageData(
      lines: results[0] as List<MushafLine>,
      fontFamily: results[1] as String,
    );
  }

  @override
  Widget build(BuildContext context) {
    final localization = AppLocalizations.of(context);

    return FutureBuilder<_MushafPageData>(
      future: _pageFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                '${localization.translate('mushafPageLoadError')}\n'
                    '${snapshot.error}',
                textAlign: TextAlign.center,
              ),
            ),
          );
        }

        final data = snapshot.data;

        if (data == null || data.lines.isEmpty) {
          return Center(
            child: Text(
              localization.translate('mushafPageEmpty'),
            ),
          );
        }

        return _MushafPageView(
          lines: data.lines,
          fontFamily: data.fontFamily,
          readingMode: widget.readingMode,
        );
      },
    );
  }
}

class _MushafPageView extends StatelessWidget {
  const _MushafPageView({
    required this.lines,
    required this.fontFamily,
    required this.readingMode,
  });

  static const int _mushafGridLineCount = 15;

  static const double _referenceWidth = 1000;
  static const double _ayahFontSize = 62;
  static const double _lineHeight = 86;
  static const double _horizontalPadding = 20;
  static const double _verticalPadding = 8;

  final List<MushafLine> lines;
  final String fontFamily;
  final MushafReadingMode readingMode;

  bool get isNightMode {
    return readingMode == MushafReadingMode.night;
  }

  double get _referenceHeight {
    return (_lineHeight * _mushafGridLineCount) +
        (_verticalPadding * 2);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (!constraints.maxWidth.isFinite ||
            !constraints.maxHeight.isFinite ||
            constraints.maxWidth <= 0 ||
            constraints.maxHeight <= 0) {
          return const SizedBox.shrink();
        }

        return SizedBox.expand(
          child: FittedBox(
            fit: BoxFit.contain,
            alignment: Alignment.center,
            child: SizedBox(
              width: _referenceWidth,
              height: _referenceHeight,
              child: _buildMushafBlock(),
            ),
          ),
        );
      },
    );
  }

  Widget _buildMushafBlock() {
    final linesByNumber = <int, MushafLine>{
      for (final line in lines) line.lineNumber: line,
    };

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: _horizontalPadding,
        vertical: _verticalPadding,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(
          _mushafGridLineCount,
              (index) {
            final line = linesByNumber[index + 1];

            return SizedBox(
              width: _referenceWidth - (_horizontalPadding * 2),
              height: _lineHeight,
              child: line == null
                  ? const SizedBox.shrink()
                  : _buildLine(line),
            );
          },
        ),
      ),
    );
  }

  Widget _buildLine(MushafLine line) {
    if (line.isSurahName) {
      return _buildSurahHeader(line);
    }

    if (line.isBasmallah) {
      return _buildBasmallah();
    }

    if (line.isAyah) {
      return _buildAyahLine(line);
    }

    return const SizedBox.shrink();
  }

  Widget _buildSurahHeader(MushafLine line) {
    final surahNumber = line.surahNumber;

    if (surahNumber == null) {
      return const SizedBox.shrink();
    }

    return Center(
      child: SizedBox(
        width: _referenceWidth - (_horizontalPadding * 2),
        height: _lineHeight * 0.9,
        child: HeaderWidget(
          suraNumber: surahNumber,
          theme: isNightMode
              ? const QcfThemeData(
            headerBackgroundColor: Colors.transparent,
            headerTextColor: Color(0xFF2F3D36),
          )
              : null,
        ),
      ),
    );
  }

  Widget _buildBasmallah() {
    return Center(
      child: Text(
        '﷽',
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.center,
        maxLines: 1,
        softWrap: false,
        style: TextStyle(
          fontFamily: fontFamily,
          fontSize: _ayahFontSize * 0.88,
          height: 1,
          color: isNightMode
              ? const Color(0xFFF2F2F2)
              : null,
        ),
      ),
    );
  }

  Widget _buildAyahLine(MushafLine line) {
    return Center(
      child: Text(
        line.text,
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.center,
        maxLines: 1,
        softWrap: false,
        overflow: TextOverflow.clip,
        style: TextStyle(
          fontFamily: fontFamily,
          fontSize: _ayahFontSize,
          height: 1,
          color: isNightMode
              ? const Color(0xFFF2F2F2)
              : null,
        ),
      ),
    );
  }
}

class _MushafPageData {
  const _MushafPageData({
    required this.lines,
    required this.fontFamily,
  });

  final List<MushafLine> lines;
  final String fontFamily;
}