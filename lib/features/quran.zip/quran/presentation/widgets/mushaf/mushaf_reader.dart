import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:qcf_quran/qcf_quran.dart';

import '../../cubit/mushaf_theme_cubit.dart';
import '../../cubit/mushaf_theme_state.dart';
import 'fixed_qcf_page.dart';

class MushafReader extends StatefulWidget {
  const MushafReader({
    super.key,
    required this.surahNumber,
    required this.onPageChanged,
    this.onInitialPageResolved,
    this.initialPageNumber,
  });

  final int surahNumber;
  final int? initialPageNumber;
  final ValueChanged<int> onPageChanged;
  final ValueChanged<int>? onInitialPageResolved;

  @override
  State<MushafReader> createState() => _MushafReaderState();
}

class _MushafReaderState extends State<MushafReader> {
  static const int _totalPages = 604;

  late final int _initialPageNumber;
  late final PageController _pageController;

  @override
  void initState() {
    super.initState();

    _initialPageNumber = _resolveInitialPageNumber();

    _pageController = PageController(
      initialPage: _initialPageNumber - 1,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.onInitialPageResolved?.call(_initialPageNumber);
    });
  }

  int _resolveInitialPageNumber() {
    final requestedPage = widget.initialPageNumber;

    if (requestedPage != null) {
      return requestedPage.clamp(1, _totalPages);
    }

    return getPageNumber(widget.surahNumber, 1);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MushafThemeCubit, MushafThemeState>(
      builder: (context, state) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: PageView.builder(
            controller: _pageController,
            physics: const PageScrollPhysics(),
            itemCount: _totalPages,
            onPageChanged: (index) {
              widget.onPageChanged(index + 1);
            },
            itemBuilder: (context, index) {
              return FixedQcfPage(
                pageNumber: index + 1,
                readingMode: state.readingMode,
              );
            },
          ),
        );
      },
    );
  }
}